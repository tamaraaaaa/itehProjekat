<?php header("Content-type: atom+xml") ?>
<root>
	<element />
</root>