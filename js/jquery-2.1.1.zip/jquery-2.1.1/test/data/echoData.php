<?php echo file_get_contents('php://input'); ?>
